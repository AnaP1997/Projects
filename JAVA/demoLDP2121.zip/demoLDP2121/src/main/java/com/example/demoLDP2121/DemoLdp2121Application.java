package com.example.demoLDP2121;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoLdp2121Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoLdp2121Application.class, args);
	}

}
