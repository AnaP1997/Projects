package com.example.demoLDP2121;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoLdp2121ApplicationTests {

	@Test
	void contextLoads() {
	}

}
