package com.example.demoLDP2121B;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoLdp2121BApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoLdp2121BApplication.class, args);
	}

}
